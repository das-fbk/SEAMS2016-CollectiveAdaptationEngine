library(splitstackshape)
library(plyr)
library(vioplot)

toPdf <- FALSE
fileName <- "exec_time.pdf"

universe_rasp <- merge(treatments_rasp, results_rasp,by="id")
universe_rasp$dv1 <- universe_rasp$dv1 / 1000000 # in seconds
universe_rasp$dv2 <- universe_rasp$dv2 / (1024 * 1024) # in Megabyte

universe_comp02 <- merge(treatments_comp02, results_comp02,by="id")
universe_comp02$dv1 <- universe_comp02$dv1 / 1000000 # in seconds
universe_comp02$dv2 <- universe_comp02$dv2 / (1024 * 1024) # in Megabyte

myvar = function(v) {
  m = mean(v)
  mean((m - v)^2)
}

if(toPdf) {
  setupPdf()
}

exec_time_issues <- function() {
  x1 <- universe_comp02$dv1[universe_comp02$iv1==1]
  x2 <- universe_comp02$dv1[universe_comp02$iv1==250]
  x3 <- universe_comp02$dv1[universe_comp02$iv1==500]
  x4 <- universe_comp02$dv1[universe_comp02$iv1==750]
  x5 <- universe_comp02$dv1[universe_comp02$iv1==1000]
  x1r <- universe_rasp$dv1[universe_rasp$iv1==1]
  x2r <- universe_rasp$dv1[universe_rasp$iv1==250]
  x3r <- universe_rasp$dv1[universe_rasp$iv1==500]
  x4r <- universe_rasp$dv1[universe_rasp$iv1==750]
  x5r <- universe_rasp$dv1[universe_rasp$iv1==1000]
  print(myvar(x1))
  print(myvar(x1r))
  print(myvar(x2))
  print(var(x2r))
  print(var(x3))
  print(var(x3r))
  print(var(x4))
  print(var(x4r))
  print(var(x5))
  print(x5r)
  print(mean(x5r))
  print(max(x5r))
  p <- boxplot(x1, x1r, x2, x2r, x3, x3r, x4, x4r, x5, x5r, names=c("1-M", "1-R", "250-M", "250-R", "500-M", "500-R", "750-M", "750-R", "1000-M", "1000-R"), col="grey", drawRect=TRUE, wex=0.5)
  text(y=c(700,700,700,1700,700, 4000,750,6200,1000,8200), labels=c(round(mean(x1), 2), round(mean(x1r), 2), round(mean(x2), 2), round(mean(x2r), 2), round(mean(x3), 2), round(mean(x3r), 2), round(mean(x4), 2), round(mean(x4r), 2), round(mean(x5), 2), round(mean(x5r), 2)), x = c(1,2,3,4,5,6,7,8,9,10), col="red")
  #title("Execution time per number of raised issues (in milliseconds)")
}

memory_issues <- function() {
  #universe$dv2 <- universe$dv2
  x1 <- universe$dv2[universe$iv1==1]
  x2 <- universe$dv2[universe$iv1==250]
  x3 <- universe$dv2[universe$iv1==500]
  x4 <- universe$dv2[universe$iv1==750]
  x5 <- universe$dv2[universe$iv1==1000]
  p <- boxplot(x1, x2, x3, x4, x5, names=c("1", "250", "500", "750", "1000"), col="grey", drawRect=TRUE, wex=0.5, range=50)
  text(y=c(40,40,40,40,40), labels=c(round(mean(x1), 6), round(mean(x2), 6), round(mean(x3), 6), round(mean(x4), 6), round(mean(x5), 6)), x = c(1,2,3,4,5), col="red")
  title("Memory consumption per number of raised issues (in Megabytes)")
}

cpu_time_issues <- function() {
  x1 <- universe$dv3[universe$iv1==1]
  x2 <- universe$dv3[universe$iv1==250]
  x3 <- universe$dv3[universe$iv1==500]
  x4 <- universe$dv3[universe$iv1==750]
  x5 <- universe$dv3[universe$iv1==1000]
  p <- boxplot(x1, x2, x3, x4, x5, names=c("1", "250", "500", "750", "1000"), col="grey", drawRect=TRUE, wex=0.5)
  text(y=c(40,40,40,40,40), labels=c(round(mean(x1), 6), round(mean(x2), 6), round(mean(x3), 6), round(mean(x4), 6), round(mean(x5), 6)), x = c(1,2,3,4,5), col="red")
  title("CPU time per number of raised issues (in milliseconds)")
}

exec_time_issues()
#memory_issues()
#cpu_time_issues()

if(toPdf) {
  dev.off()
}

setupPdf <- function() {
  margin <- 4
  pdf(fileName)
  par(mar=c(margin, margin, margin, margin))
  par(mfrow=c(1, 1))
  par(las=1)
}
